/*
 Cavallini Nicolò       30/04/2020
 Scrivere una funzione che restituisca un valore booleano vero o falso controllando se due rette di cui si conoscono le equazioni, y=m1+q1 e y=m2+q2
 verifica se sono perpendicolari
 verifica inoltre se non sono parallele il punto di intersezione
 */
#include <stdio.h>
#include "mylib.h"

int main() {
    int m1, m2, q1, q2;
    
    printf("Inserisci il valore m1: ");
    scanf("%d", &m1);
    printf("Inserisci il valore m2: ");
    scanf("%d", &m2);
    printf("Inserisci il valore q1: ");
    scanf("%d", &q1);
    printf("Inserisci il valore q2: ");
    scanf("%d", &q2);
    
    if(m1==m2){
        printf("Le due rette sono parallele");
    }
    else{
        printf("Le due rette non sono parallele");
        trovax(m1, m2, q1, q2);
        trovay(m1, q1);
        
    }
    if(m1==-1/m2){
        printf("Le due rette sono perpendicolari");
    }
    else{
        printf("Le due rette non sono perpendicolari");
    }
}
