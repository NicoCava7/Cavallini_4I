#include "mylib.h"
float x;

void trovax(int m1, int m2, int q1, int q2){
    x=(float)(q2-q1)/(m1-m2);
    printf("la x vale: %f\n2", x);
}

void trovay(int m1, int q1){
    float y;
    y=(float)((m1*x)+q1);
    printf("la y vale: %f", y);
}
