#include <stdio.h>
#include <stdlib.h>

void trovax(int, int, int, int);
void trovay(int, int);
